"""Shared constants and pure helpers for the release-decision verifier.

The verifier re-derives the correct promotion decision from the two read-only
canonical sources the reconciliation step must reconcile:

* the H2 experiment database — authoritative for validation metrics,
  feature-hash lineage, and calibration status, and
* the model-registry HTTP API — authoritative for candidate identity.

Nothing here hardcodes a winning model id; the expected decision falls out of
the live data evaluated against the documented policy gates. This keeps the
grader honest in a shared verifier container (the agent cannot satisfy the
suite by copying a literal answer out of the test source).
"""

from __future__ import annotations

import csv
import glob
import subprocess
import tempfile
from pathlib import Path


# --- Pinned locations (scaffold_plan.thresholds[]) --------------------------
APP = Path("/app")
MANIFEST_PATH = APP / "build" / "release-decision.json"
SCHEMA_PATH = APP / "schemas" / "release-decision.schema.json"
API_BASE_URL = "http://localhost:8080"
CANDIDATES_URL = f"{API_BASE_URL}/models/candidates"
# Exact JDBC URL for the embedded H2 experiment DB (scaffold_plan.thresholds).
H2_JDBC_URL = "jdbc:h2:file:/app/experiment-db/experiments"

# Promotion-gate thresholds are the documented policy constants from
# environment/policy/promotion-policy.md (Gate 1). They mirror the authored
# policy prose; keep them in sync with that file if the policy is ever retuned.
AUC_FLOOR = 0.80
ACCURACY_FLOOR = 0.75

# Float tolerance for metric comparisons.
TOL = 1e-9


def find_h2_jar() -> str:
    """Locate the H2 driver jar warmed into the local Maven repository."""
    matches = glob.glob("/root/.m2/repository/com/h2database/h2/*/h2-*.jar")
    jars = [m for m in matches if not m.endswith(("-sources.jar", "-javadoc.jar"))]
    assert jars, "H2 driver jar not found in the local Maven repository"
    return sorted(jars)[-1]


def h2_select(sql: str) -> list[dict[str, str]]:
    """Run a read-only SELECT against the H2 experiment DB, return rows as dicts.

    Uses H2's CSVWRITE via the driver jar so the pure-Python verifier can read
    the Java-native database file without a JDBC binding. Column keys are
    lower-cased for stable access regardless of H2's identifier casing.
    """
    jar = find_h2_jar()
    safe_sql = sql.replace("'", "''")
    with tempfile.TemporaryDirectory() as tmp:
        out_csv = Path(tmp) / "out.csv"
        script = Path(tmp) / "query.sql"
        script.write_text(
            f"CALL CSVWRITE('{out_csv}', '{safe_sql}');\n", encoding="utf-8"
        )
        result = subprocess.run(
            [
                "java", "-cp", jar, "org.h2.tools.RunScript",
                "-url", H2_JDBC_URL, "-user", "sa", "-script", str(script),
            ],
            capture_output=True,
            text=True,
            timeout=90,
        )
        assert result.returncode == 0, (
            f"H2 query failed for {sql!r}:\n{result.stdout}\n{result.stderr}"
        )
        with out_csv.open(newline="", encoding="utf-8") as handle:
            return [
                {key.lower(): value for key, value in row.items()}
                for row in csv.DictReader(handle)
            ]


def gate_failures(model_id: str, h2_evidence: dict, registry: dict) -> list[str]:
    """Return the list of policy gates a model fails, evaluated against H2 canon.

    Empty list == the model passes all three gates and is eligible for promotion.
    """
    fails: list[str] = []
    auc, accuracy = h2_evidence["metrics"][model_id]
    if auc < AUC_FLOOR or accuracy < ACCURACY_FLOOR:
        fails.append("metric_threshold")
    if not h2_evidence["calibrated"].get(model_id, False):
        fails.append("uncalibrated")
    registry_hash = registry[model_id].get("featureHash")
    if registry_hash != h2_evidence["lineage"].get(model_id):
        fails.append("lineage_mismatch")
    return fails


def norm_field(name: str) -> str:
    """Normalize a conflict field label so naming variants compare equal.

    e.g. "feature_hash", "featureHash", "feature-hash-lineage" -> "featurehash".
    """
    return "".join(ch for ch in name.lower() if ch.isalnum())


def resolve_model_id(value, registry: dict) -> str | None:
    """Map a manifest model reference back to a registry candidate id.

    Accepts the registry identity fields (id / name / version) so the grader
    does not force a specific identifier convention on the agent.
    """
    for model_id, candidate in registry.items():
        if value in (candidate.get("id"), candidate.get("name"), candidate.get("version")):
            return model_id
    return None
