"""Verifier tests for reconcile-spring-boot-model-registry-with-h2-experiment.

Each test maps to a functional_criteria[] entry in scaffold_plan.yaml and grades
the agent-produced build/release-decision.json against the canonical promotion
decision recomputed from the live H2 experiment DB and the registry API.

Run via tests/test.sh, which writes /logs/verifier/reward.txt.
"""

from __future__ import annotations

import json

import jsonschema

from helpers import (
    MANIFEST_PATH,
    SCHEMA_PATH,
    TOL,
    gate_failures,
    norm_field,
    resolve_model_id,
)


def test_manifest_exists_and_valid_json():
    """functional_criteria[id=manifest_exists_and_valid_json]: the decision manifest exists and parses as JSON."""
    assert MANIFEST_PATH.is_file(), f"missing manifest at {MANIFEST_PATH}"
    # Raises json.JSONDecodeError (test fails) if the file is not valid JSON.
    json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def test_manifest_conforms_to_schema(manifest):
    """functional_criteria[id=manifest_conforms_to_schema]: manifest validates against the release-decision JSON Schema."""
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    # Raises jsonschema.ValidationError (test fails) on any schema violation.
    jsonschema.validate(instance=manifest, schema=schema)


def test_required_decision_fields_present(manifest):
    """functional_criteria[id=required_decision_fields_present]: promoted/rejected/conflicts have the expected shapes."""
    assert {"promoted", "rejected", "conflicts"} <= set(manifest)

    assert manifest["promoted"] is None or isinstance(manifest["promoted"], str), (
        "promoted must be a model identifier string or null"
    )

    assert isinstance(manifest["rejected"], list)
    for entry in manifest["rejected"]:
        assert isinstance(entry.get("model"), str), "rejected[].model must be a string"
        reasons = entry.get("reasons")
        assert isinstance(reasons, list) and reasons, "rejected[].reasons must be a non-empty list"
        assert all(isinstance(reason, str) for reason in reasons)

    assert isinstance(manifest["conflicts"], list)
    for conflict in manifest["conflicts"]:
        assert {"model", "field", "api_value", "db_value", "canonical_source"} <= set(conflict), (
            "each conflict must enumerate model/field/api_value/db_value/canonical_source"
        )


def test_promoted_model_is_policy_safe(manifest, h2_evidence, registry, expected):
    """functional_criteria[id=promoted_model_is_policy_safe]: the promoted model passes every policy gate against H2 canon."""
    promoted = manifest["promoted"]
    assert promoted is not None, "a candidate qualifies under the policy but none was promoted"

    model_id = resolve_model_id(promoted, registry)
    assert model_id is not None, f"promoted value {promoted!r} does not identify a known candidate"

    failures = gate_failures(model_id, h2_evidence, registry)
    assert failures == [], f"promoted model {model_id} violates policy gate(s): {failures}"

    # Exactly the unique candidate that the policy makes promotable.
    assert model_id == expected["promoted"], (
        f"promoted {model_id!r}; policy makes {expected['promoted']!r} the safe choice"
    )


def test_rejected_models_have_valid_reasons(manifest, h2_evidence, registry, expected):
    """functional_criteria[id=rejected_models_have_valid_reasons]: every rejected model genuinely fails a gate (or lost the tie-break), and no promotable model is rejected."""
    rejected_ids: list[str] = []
    for entry in manifest["rejected"]:
        model_id = resolve_model_id(entry["model"], registry)
        assert model_id is not None, f"rejected entry {entry['model']!r} is not a known candidate"
        rejected_ids.append(model_id)

        fails_a_gate = bool(gate_failures(model_id, h2_evidence, registry))
        lost_tiebreak = model_id in expected["qualifiers"] and model_id != expected["promoted"]
        assert fails_a_gate or lost_tiebreak, (
            f"model {model_id} is rejected but passes every gate and did not lose a tie-break"
        )

    assert expected["promoted"] not in rejected_ids, "a promotable model was rejected"
    # Policy requires every non-promoted candidate to be listed in rejected.
    assert set(rejected_ids) == expected["rejected"], (
        f"rejected set {set(rejected_ids)} != expected non-promoted set {expected['rejected']}"
    )


def test_uncalibrated_model_not_promoted(manifest, h2_evidence, registry):
    """functional_criteria[id=uncalibrated_model_not_promoted]: an uncalibrated model is never promoted and is listed as rejected."""
    promoted = manifest["promoted"]
    if promoted is not None:
        model_id = resolve_model_id(promoted, registry)
        assert model_id is not None
        assert h2_evidence["calibrated"].get(model_id, False) is True, (
            f"promoted model {model_id} is uncalibrated per the H2 calibration_status table"
        )

    uncalibrated = {mid for mid, ok in h2_evidence["calibrated"].items() if not ok}
    rejected_ids = {resolve_model_id(entry["model"], registry) for entry in manifest["rejected"]}
    for model_id in uncalibrated:
        assert model_id in rejected_ids, f"uncalibrated model {model_id} is not listed as rejected"


def test_conflicts_reconciled_with_canonical_source(manifest, h2_evidence, registry, expected):
    """functional_criteria[id=conflicts_reconciled_with_canonical_source]: every API-vs-DB discrepancy is recorded with H2 as canonical."""
    reported: set[tuple[str, str]] = set()
    for conflict in manifest["conflicts"]:
        model_id = resolve_model_id(conflict["model"], registry)
        assert model_id is not None, f"conflict references unknown model {conflict['model']!r}"
        assert conflict["canonical_source"] == "h2", (
            f"H2-canonical field {conflict['field']!r} for {model_id} must use canonical_source 'h2'"
        )
        reported.add((model_id, norm_field(conflict["field"])))

    assert reported == expected["conflicts"], (
        f"conflict set mismatch: reported {reported}, expected {expected['conflicts']}"
    )

    # Recorded api/db values must match the real registry-vs-H2 discrepancy.
    for conflict in manifest["conflicts"]:
        model_id = resolve_model_id(conflict["model"], registry)
        field = norm_field(conflict["field"])
        if field == "featurehash":
            assert str(conflict["db_value"]) == h2_evidence["lineage"][model_id], (
                f"db_value for {model_id} feature-hash must be the H2 canonical hash"
            )
            assert str(conflict["api_value"]) == registry[model_id]["featureHash"], (
                f"api_value for {model_id} feature-hash must be the registry-reported hash"
            )
        elif field in ("auc", "accuracy"):
            index = 0 if field == "auc" else 1
            assert abs(float(conflict["db_value"]) - h2_evidence["metrics"][model_id][index]) <= TOL, (
                f"db_value for {model_id} {field} must be the H2 canonical metric"
            )
            assert abs(float(conflict["api_value"]) - float(registry[model_id]["metrics"][field])) <= TOL, (
                f"api_value for {model_id} {field} must be the registry-reported metric"
            )
