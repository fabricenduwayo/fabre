"""Pytest fixtures for the release-decision verifier.

These fixtures load the agent-produced manifest and recompute the canonical
promotion decision from the live H2 experiment DB and the running registry API.
The pure helpers they build on live in ``helpers.py``.
"""

from __future__ import annotations

import json
import time

import pytest
import requests

from helpers import (
    CANDIDATES_URL,
    MANIFEST_PATH,
    TOL,
    gate_failures,
    h2_select,
)


@pytest.fixture(scope="session")
def manifest() -> dict:
    """Parse the agent-produced release-decision manifest."""
    assert MANIFEST_PATH.is_file(), f"expected manifest at {MANIFEST_PATH}"
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


@pytest.fixture(scope="session")
def h2_evidence() -> dict:
    """Canonical validation evidence read from the H2 experiment database."""
    metrics = {
        row["model_id"]: (float(row["auc"]), float(row["accuracy"]))
        for row in h2_select("SELECT model_id, auc, accuracy FROM validation_metrics")
    }
    lineage = {
        row["model_id"]: row["feature_hash"]
        for row in h2_select("SELECT model_id, feature_hash FROM feature_hash_lineage")
    }
    calibrated = {
        row["model_id"]: row["calibrated"].strip().upper() in ("TRUE", "1", "T")
        for row in h2_select("SELECT model_id, calibrated FROM calibration_status")
    }
    assert metrics, "no validation_metrics rows returned from the H2 experiment DB"
    return {"metrics": metrics, "lineage": lineage, "calibrated": calibrated}


@pytest.fixture(scope="session")
def registry() -> dict:
    """Candidate metadata as reported by the running registry API, keyed by id."""
    deadline = time.monotonic() + 30
    last_error = "no attempt made"
    while time.monotonic() < deadline:
        try:
            response = requests.get(CANDIDATES_URL, timeout=5)
        except requests.RequestException as exc:
            last_error = str(exc)
        else:
            if response.status_code == 200:
                return {candidate["id"]: candidate for candidate in response.json()}
            last_error = f"status {response.status_code}"
        time.sleep(1)
    raise AssertionError(
        f"registry API {CANDIDATES_URL} never became ready: {last_error}"
    )


@pytest.fixture(scope="session")
def expected(h2_evidence: dict, registry: dict) -> dict:
    """Recompute the canonical decision from live evidence + the policy gates."""
    model_ids = list(registry)
    failures = {mid: gate_failures(mid, h2_evidence, registry) for mid in model_ids}
    qualifiers = [mid for mid in model_ids if not failures[mid]]
    # Tie-break: highest canonical AUC, then lexicographically smallest id.
    qualifiers_ranked = sorted(
        qualifiers, key=lambda mid: (-h2_evidence["metrics"][mid][0], mid)
    )
    promoted = qualifiers_ranked[0] if qualifiers_ranked else None

    conflicts: set[tuple[str, str]] = set()
    for mid in model_ids:
        candidate = registry[mid]
        registry_auc = float(candidate["metrics"]["auc"])
        registry_accuracy = float(candidate["metrics"]["accuracy"])
        h2_auc, h2_accuracy = h2_evidence["metrics"][mid]
        if abs(registry_auc - h2_auc) > TOL:
            conflicts.add((mid, "auc"))
        if abs(registry_accuracy - h2_accuracy) > TOL:
            conflicts.add((mid, "accuracy"))
        if candidate.get("featureHash") != h2_evidence["lineage"].get(mid):
            conflicts.add((mid, "featurehash"))

    return {
        "promoted": promoted,
        "qualifiers": set(qualifiers),
        "failures": failures,
        "rejected": {mid for mid in model_ids if mid != promoted},
        "conflicts": conflicts,
    }
