#!/bin/bash

if [ "$PWD" = "/" ]; then
    echo "Error: No working directory set. Please set a WORKDIR in your Dockerfile before running this script."
    exit 1
fi

mkdir -p /logs/verifier

# pytest + pytest-json-ctrf are pre-installed in the image (allow_internet=false,
# so no wheels are resolved at grade time). Pytest drives the Java system under
# test directly via HTTP (registry API) and the H2 driver jar.
python -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA
code=$?

echo "pytest exit code: ${code}"

if [ "$code" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
