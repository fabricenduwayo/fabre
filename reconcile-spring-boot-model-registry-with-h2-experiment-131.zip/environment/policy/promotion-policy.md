# Churn Model Promotion Policy

This document defines the rules the `reconcile-model-release` step applies when
deciding whether a candidate churn model is safe to promote to the `production`
alias. A promotion decision is made by evaluating every candidate model against
the gates below and selecting at most one winner. The policy is written so that
the promote/reject outcome is fully determined by the H2 experiment DB canonical
evidence together with the model-registry metadata — there is no discretionary
judgement.

## Sources of truth

Two systems describe each candidate. They are canonical for different fields,
and they must not be treated interchangeably.

| Field | Canonical source |
| --- | --- |
| Validation AUC | H2 experiment DB (`validation_metrics`) |
| Validation accuracy | H2 experiment DB (`validation_metrics`) |
| Feature-hash lineage | H2 experiment DB (`feature_hash_lineage`) |
| Calibration status | H2 experiment DB (`calibration_status`) |
| Candidate identity (id / name / version) | Registry API |
| Deployment aliases | Registry API |

When the registry API and the H2 experiment DB disagree on a field that this
table marks canonical to H2 (AUC, accuracy, feature-hash lineage, or calibration
status), the H2 value is authoritative and the registry value is ignored for the
gate evaluation. Every such disagreement must be recorded in the decision
manifest under `conflicts`.

## Promotion gates

A model is eligible for promotion only if it passes all three gates below. The
gates are evaluated against the H2 canonical evidence for that model and version.

### Gate 1 — Validation-metric thresholds

Both thresholds must hold, evaluated against the H2 canonical `validation_metrics`:

| Metric | Requirement |
| --- | --- |
| AUC | must be greater than or equal to 0.80 |
| Accuracy | must be greater than or equal to 0.75 |

A model whose canonical AUC is below 0.80, or whose canonical accuracy is below
0.75, fails this gate.

### Gate 2 — Calibration

A model must be calibrated to be eligible for promotion. Calibration is read
from the H2 canonical `calibration_status.calibrated` flag: the model passes this
gate only when `calibrated` is `TRUE`.

An uncalibrated model (`calibrated = FALSE`) must not be promoted even if its
validation metrics pass Gate 1.

### Gate 3 — Feature-hash lineage consistency

The feature-hash reported by the registry API for the model must match the H2
canonical `feature_hash_lineage` value for that model and version. If the two
hashes match, the lineage is consistent and the model passes this gate. If they
differ, the lineage is inconsistent and the model must not be promoted.

## Promotion decision rule

1. Evaluate every candidate against Gate 1, Gate 2, and Gate 3.
2. A candidate qualifies only if it passes all three gates.
3. If exactly one candidate qualifies, promote it.
4. If more than one candidate qualifies, apply the tie-break below and promote
   the single winner.
5. If no candidate qualifies, promote none — set `promoted` to `null`.

Every candidate that is not promoted must appear in `rejected`, each annotated
with its failing reason or reasons. A candidate may fail more than one gate; all
failing reasons are listed. The qualifying-but-not-selected candidates in a
tie-break are also listed in `rejected` (their reason being that another
candidate won the tie-break).

### Tie-break

When more than one candidate passes all gates, select the winner as follows:

1. Choose the candidate with the highest canonical AUC (from the H2
   `validation_metrics`).
2. If two or more candidates are still tied on canonical AUC, choose the one
   whose model id is lexicographically smallest.

This procedure always resolves to a single winner because model ids are unique.

## Decision manifest expectations

The decision produced by `reconcile-model-release` must be reproducible from the
inputs described above. The manifest records:

- `promoted`: the id/name/version of the single promoted model (registry
  identity fields), or `null` when no candidate passes all gates.
- `rejected`: every non-promoted candidate with its failing gate reason(s).
- `conflicts`: every field where the registry API disagreed with the H2 canonical
  value on an H2-canonical field, with H2 recorded as the authoritative value.

No gate beyond the three defined here is applied. The thresholds (AUC >= 0.80,
accuracy >= 0.75) are exact and are not rounded, relaxed, or supplemented.
