# Placeholder instruction — Scaffold harbor_smoke stub.
# Replace with the real instruction at human handoff.
# Harbor's Task validator requires this file to exist; the file's
# contents are not consulted by harbor_smoke.
